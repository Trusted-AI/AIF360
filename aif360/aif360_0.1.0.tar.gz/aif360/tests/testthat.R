library(testthat)
test_check("aif360")
